module TestUpload
  def self.init
    Reloaded::ModAPI.logc('TestUpload initialized', :info)   # optional
    # mod setup...
  end
end

TestUpload.init
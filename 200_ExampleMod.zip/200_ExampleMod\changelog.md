﻿Example Mod - Changelog

[1.0.0] - 06-20-2026
### Added
- Initial release of Example Mod.
- Added `example_bool` toggle setting (default: on).
- Added `example_text` string setting (default: "hello").

### Notes
- This mod intentionally declares a missing dependency (`999_FakeMod`) to
  demonstrate how the loader handles unmet dependencies. It will be listed
  as skipped in `Reloaded/Logging/Mods.txt` with reason "missing dependency".
- Remove or satisfy the dependency to see the mod load normally.

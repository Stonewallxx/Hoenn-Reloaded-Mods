module ExampleMod
  def self.init
    Reloaded::ModAPI.logc('ExampleMod initialized', :info)   # optional
    # mod setup...
  end
end

ExampleMod.init
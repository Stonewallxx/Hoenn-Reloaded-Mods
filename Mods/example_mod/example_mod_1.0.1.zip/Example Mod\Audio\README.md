# Audio

Place example audio assets here.

Keep filenames clear and avoid replacing base-game audio unless the mod is
explicitly designed to do so.

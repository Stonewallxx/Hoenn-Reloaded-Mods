# Graphics

Place example graphics assets here.

The Reloaded asset resolver can find files in this folder without copying them
into the base game folders.

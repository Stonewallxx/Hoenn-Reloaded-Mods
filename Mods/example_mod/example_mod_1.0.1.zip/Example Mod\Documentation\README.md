# Example Mod

This mod demonstrates the recommended Hoenn Reloaded mod structure.

## Included Examples

- `mod.json` with required and optional metadata fields.
- `Settings.json` with toggle, enum, slider, number, header, and spacer fields.
- `Scripts/001_example_mod.rb` with safe logging and event usage.
- Asset folders for `Graphics/` and `Audio/`.

## Publishing

Use:

```text
Mod Manager -> Tools -> Publish
```

Then choose:

```text
Mod -> example_mod
```

The publisher validates the mod before uploading it.

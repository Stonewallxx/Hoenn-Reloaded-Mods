#======================================================
# Example Mod Script
# Author: Stonewall
#======================================================
# Minimal safe script used to demonstrate Reloaded mod loading.
#
# Responsibilities:
#   - Show how a mod can read Reloaded settings.
#   - Show how a mod can write to Reloaded logs.
#   - Show how a mod can subscribe to a Reloaded event.
#
#======================================================

module ExampleMod
  MOD_ID = "example_mod"

  def self.enabled_message?
    return true unless defined?(Reloaded::ModSettings)
    Reloaded::ModSettings.get(MOD_ID, "enable_example_message", true)
  rescue
    true
  end

  def self.mode
    return "Normal" unless defined?(Reloaded::ModSettings)
    Reloaded::ModSettings.get(MOD_ID, "example_mode", "Normal")
  rescue
    "Normal"
  end

  def self.log(message)
    if defined?(Reloaded::Log)
      Reloaded::Log.mod(MOD_ID, message)
    else
      puts("[ExampleMod] #{message}") rescue nil
    end
  end

  def self.boot
    return unless enabled_message?
    log("Example Mod loaded in #{mode} mode.")
  end
end

if defined?(Reloaded::Events)
  Reloaded::Events.on(:mods_loaded, :example_mod_boot, priority: 100) do |_ctx|
    ExampleMod.boot
  end
else
  ExampleMod.boot
end
